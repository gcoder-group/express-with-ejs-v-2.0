# express-with-ejs

Run the command npm install
and npm start
