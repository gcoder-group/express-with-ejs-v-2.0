
var config = {
	SMTP_HOST : "smtp.gmail.com",
	SMTP_PORT : "465",
	SMTP_USER : "testecove@gmail.com",
	SMTP_PASSWORD : "mxigchohkfqlpbkb",
	FROM_NAME : "Zeligz Techonolgy",
	FROM_EMAIL : "testecove@gmail.com",
	

	CAPTCHA_LOGIN : true,

	role_user_id : '5d3c8dc0a3c9641bfc7f28e0'
}

module.exports = config;